---
name: Verba Feature Template
about: Request a new feature for Verba
title: ""
labels: "enhancement"
assignees: ""
---

## Description

<!-- A clear and concise description of what the new feature. -->

## Additional context

<!-- Add any other context about the problem here. -->
